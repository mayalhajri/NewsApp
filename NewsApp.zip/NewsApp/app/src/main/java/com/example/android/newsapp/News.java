package com.example.android.newsapp;


public class News {

    private String mTitle;
    private String mAuthor;
    private String mWebUrl;
    private String mSection;
    private String mDate;

    public News(String title, String author, String webUrl, String section, String date) {
        mTitle = title;
        mAuthor = author;
        mWebUrl = webUrl;
        mSection = section;
        mDate = date;
    }

    public String getTitle() {
        return mTitle;
    }

    public String getAuthor() {
        return mAuthor;
    }

    public String getWebUrl() {
        return mWebUrl;
    }

    public String getSection() {
        return mSection;
    }

    public String getDate() {
        return mDate;
    }

}
